# Running tests

The test suite can be ran using `make test`.

To run the individual tests locally do the following;
```
assets/ci/run.sh --suite Pongo assets/ci/pongo_docker.test.sh
```
