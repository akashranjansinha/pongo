return {
  postgres = {
    up = [[
    ]],
  },
  cassandra = {
    up = [[
    ]],
  }
}
