return {
  foos = {
    name = "foos",
    primary_key = { "color" },
    fields = {
      { color = "string" },
      { shape = "string" },
    },
  },
}
