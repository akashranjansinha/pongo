return {
  fields = {
    something = { type = "string" }
  }
}
