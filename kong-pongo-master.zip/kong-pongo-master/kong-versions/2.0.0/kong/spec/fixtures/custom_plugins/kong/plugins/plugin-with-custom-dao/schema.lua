return {
  name = "plugin-with-custom-dao",
  fields = {
    { config = {
        type = "record",
        fields = {}
    } }
  }
}
