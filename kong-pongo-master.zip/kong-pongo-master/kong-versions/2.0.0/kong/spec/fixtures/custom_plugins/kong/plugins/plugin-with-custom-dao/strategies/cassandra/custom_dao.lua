local CustomDAO = {}

function CustomDAO:custom_method()
  return "I was implemented for cassandra"
end

return CustomDAO
