return {
  name = "foreign-entity",
  fields = {
    {
      config = {
        type = "record",
        fields = {
        },
      },
    },
  },
}
