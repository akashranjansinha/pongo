return {
  name = "dummy",
  fields = {
    { config = {
        type = "record",
        fields = {
          { foo = { type = "bar" }, },
    }, }, },
  },
}
