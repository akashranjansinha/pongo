return require "spec.fixtures.custom_plugins.kong.plugins.logger.schema"
