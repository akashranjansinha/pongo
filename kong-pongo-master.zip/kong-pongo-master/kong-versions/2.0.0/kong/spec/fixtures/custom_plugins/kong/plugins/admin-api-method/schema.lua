return {
  fields = {
    foo = { type = "string" }
  }
}
