local CustomDAO = {}

function CustomDAO:custom_method()
  return "I was implemented for postgres"
end

return CustomDAO
