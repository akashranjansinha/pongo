return {
  name = "reports-api",
  fields = {
    {
      config = {
        type = "record",
        fields = {
        }
      }
    }
  }
}
