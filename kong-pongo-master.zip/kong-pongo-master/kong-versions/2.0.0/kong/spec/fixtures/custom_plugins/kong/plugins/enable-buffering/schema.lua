return {
  name = "enable-buffering",
  fields = {
    {
      config = {
        type = "record",
        fields = {
          {
            mode = {
              type = "string",
            },
          },
        },
      },
    },
  },
}
