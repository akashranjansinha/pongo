return {
  name = "unique-foreign",
  fields = {
    {
      config = {
        type = "record",
        fields = {
        }
      }
    }
  }
}
