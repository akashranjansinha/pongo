return {
  "000_base_foreign_entity",
}
